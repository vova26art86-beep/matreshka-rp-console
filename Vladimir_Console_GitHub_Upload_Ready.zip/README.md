# Vladimir Console — Matreshka RP

Централизованные userscript-обновления для форума Matreshka RP.

## Установка

1. Установи Tampermonkey.
2. Открой одну из ссылок Raw и подтверди установку.
3. В Tampermonkey включи автоматическую проверку обновлений.

### Админская панель 4.6.6

https://raw.githubusercontent.com/vova26art86-beep/matreshka-rp-console/main/vladimir-admin.user.js

### Консоль лидеров и заместителей 2.1.7

https://raw.githubusercontent.com/vova26art86-beep/matreshka-rp-console/main/vladimir-ld.user.js

## Как публиковать обновления

При следующем релизе сохраняй имена файлов `vladimir-admin.user.js` и `vladimir-ld.user.js`, увеличивай `@version` и загружай новые файлы в ветку `main`. Ссылки `@updateURL` и `@downloadURL` уже настроены на этот репозиторий.

Не добавляй сюда пароли, токены или персональные данные пользователей.
